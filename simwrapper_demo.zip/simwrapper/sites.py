#!/usr/bin/env python3
# -*- coding: utf-8 -*-

# Add more SimWrapper sites here:

sites = {
  "vsp": "https://vsp.berlin/simwrapper/",
  "asim": "https://activitysim.github.io/dashboard/"
}
